"""
The version of map manager.

Example::

	import pymapmanager as pmm
	pmm._version_
"""
__version__ = '0.2.1'

